<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application for file storage.
    |
    */

    'default' => env('FILESYSTEM_DISK', 'local'),

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Below you may configure as many filesystem disks as necessary, and you
    | may even configure multiple disks for the same driver. Examples for
    | most supported storage drivers are configured here for reference.
    |
    | Supported drivers: "local", "ftp", "sftp", "s3"
    |
    */

    'disks' => [

        'local' => [
            'driver' => 'local',
            'root' => storage_path('app/private'),
            'serve' => true,
            'throw' => false,
            'report' => false,
        ],

        'public' => [
            'driver' => 'local',
            'root' => storage_path('app/public'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],
        'brands' => [
            'driver' => 'local',
            'root' => storage_path('app/public/brands'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage/brands',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],
        'settings' => [
            'driver' => 'local',
            'root' => storage_path('app/public/settings'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage/settings',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],
        'products' => [
            'driver' => 'local',
            'root' => storage_path('app/public/products'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage/products',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],
        'categories' => [
            'driver' => 'local',
            'root' => storage_path('app/public/categories'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage/categories',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],
        'variants' => [
            'driver' => 'local',
            'root' => storage_path('app/public/variants'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage/variants',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],
        'sliders' => [
            'driver' => 'local',
            'root' => storage_path('app/public/sliders'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage/sliders',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],
        'pages' => [
            'driver' => 'local',
            'root' => storage_path('app/public/pages'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage/pages',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],

        's3' => [
            'driver' => 's3',
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'region' => env('AWS_DEFAULT_REGION'),
            'bucket' => env('AWS_BUCKET'),
            'url' => env('AWS_URL'),
            'endpoint' => env('AWS_ENDPOINT'),
            'use_path_style_endpoint' => env('AWS_USE_PATH_STYLE_ENDPOINT', false),
            'throw' => false,
            'report' => false,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Symbolic Links
    |--------------------------------------------------------------------------
    |
    | Here you may configure the symbolic links that will be created when the
    | `storage:link` Artisan command is executed. The array keys should be
    | the locations of the links and the values should be their targets.
    |
    */

    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],

];
