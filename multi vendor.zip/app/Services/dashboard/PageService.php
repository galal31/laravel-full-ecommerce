<?php

namespace App\Services\dashboard;

use App\Reposetories\dashboard\PageRepo;
use Yajra\DataTables\Facades\DataTables;

class PageService
{
    /**
     * Create a new class instance.
     */
    public function __construct(protected PageRepo $pageRepo)
    {
        //
    }

    public function PagesDataTable()
    {
        $pages = $this->pageRepo->getPages();

        return DataTables::of($pages)
            ->addIndexColumn()
            ->editColumn('slug', function ($page) {
                return "<a href='" . route('dashboard.pages.show', $page->id) . "'>" . $page->slug . '</a>';
            })
            ->addColumn('actions', function ($page) {
                return "<a href='" . route('dashboard.pages.edit', $page->id) . "' class='btn btn-primary btn-sm'>Edit</a>
                 <a href='" . route('dashboard.pages.destroy', $page->id) . "' class='btn btn-danger btn-sm'>Delete</a>";
            });
    }
}
